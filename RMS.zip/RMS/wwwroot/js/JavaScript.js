﻿function mainPageShow() {
    $("#listCont").hide();
    $("#table").hide();
    $("#addUser").hide();
    $("#mainPage").show();
}

function venueShow() {
    $("#mainPage").hide(750);
    $("#table").hide(750);
    $("#addUser").hide(750);
    $("#listCont").show(1000);
}
function tableShow() {
    $("#mainPage").hide(750);   
    $("#listCont").hide(750);
    $("#addUser").hide(750);
    $("#table").show(1000);
}
function pformShow() {
    $("#mainPage").hide(750);
    $("#listCont").hide(750);
    $("#table").hide(750);
    $("#addUser").show(1000);
}
/*
    $(document).ready(function () {
        $('input[type=button]').click(function () {
            $('#61').toggleClass('active');
        });
    });
*/

document.addEventListener("click", e => {
    if (e.target.matches("li")) {
        if (e.target.classList.contains("red")) {
            e.target.classList.add("wheat");
            e.target.classList.remove("red");
        } else {
            e.target.classList.add("red");
            e.target.classList.remove("wheat");
        }
    }
})